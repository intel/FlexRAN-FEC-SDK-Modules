var searchData=
[
  ['zc_0',['zc',['../structbblib__ldpc__decoder__5gnr__request.html#acc116a3b4e9a3c3408d121b98153f195',1,'bblib_ldpc_decoder_5gnr_request::Zc'],['../structbblib__ldpc__encoder__5gnr__request.html#a1459a410586bd730df1d2b2d9df6f502',1,'bblib_ldpc_encoder_5gnr_request::Zc'],['../structbblib__LDPC__ratematch__5gnr__request.html#aeecb67b4c26b4ae44ba2a017e7fb98f9',1,'bblib_LDPC_ratematch_5gnr_request::Zc'],['../structbblib__rate__dematching__5gnr__request.html#a76fcf16bef0ceec8b25088c2b399b9e4',1,'bblib_rate_dematching_5gnr_request::zc']]]
];
