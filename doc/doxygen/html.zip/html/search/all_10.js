var searchData=
[
  ['r_0',['r',['../structbblib__rate__match__dl__request.html#a5123031a5ec9460788cc986174b29625',1,'bblib_rate_match_dl_request']]],
  ['re_1',['re',['../structcomplex__int8__t.html#aab0a2a3c4bb99e1e5196d964a866f58b',1,'complex_int8_t::re'],['../structcomplex__int16__t.html#a26f296096f722812f876eb2bdd4c6662',1,'complex_int16_t::re'],['../structcomplex__int32__t.html#adf4a4bcbc91330ba846aebcc7595d129',1,'complex_int32_t::re'],['../structcomplex__float.html#a170e8285dc5452b1c27d6a97590509dd',1,'complex_float::re'],['../structcomplex__double.html#af3466e0949b17c561569ba827aa878f4',1,'complex_double::re']]],
  ['release_20notes_2',['Release Notes',['../index.html#rel_notes',1,'']]],
  ['requirements_20and_20dependencies_3',['System requirements and dependencies',['../user_guide.html#dependencies',1,'']]],
  ['revision_20history_4',['Revision history',['../index.html#revhist_sec',1,'']]],
  ['running_20all_20tests_5',['Running all tests',['../user_guide.html#all_tests',1,'']]],
  ['running_20the_20unit_20tests_6',['Running the unit tests',['../user_guide.html#usage_instr',1,'']]],
  ['rvid_7',['rvid',['../structbblib__rate__dematching__5gnr__request.html#abd35e3dc6df46944442b7e7c787c9d36',1,'bblib_rate_dematching_5gnr_request']]],
  ['rvidx_8',['rvidx',['../structbblib__LDPC__ratematch__5gnr__request.html#a5f0796c6ebbb4a9e856ba2f84e79ce2d',1,'bblib_LDPC_ratematch_5gnr_request::rvidx'],['../structbblib__rate__match__dl__request.html#a04af2a59d64049576b1086854920ef85',1,'bblib_rate_match_dl_request::rvidx']]]
];
