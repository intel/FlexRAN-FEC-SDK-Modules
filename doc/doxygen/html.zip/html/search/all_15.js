var searchData=
[
  ['wireless_5fsdk_5fstandard_0',['WIRELESS_SDK_STANDARD',['../user_guide.html#wireless_sdk_standard_env',1,'']]],
  ['wireless_5fsdk_5ftarget_5fisa_1',['WIRELESS_SDK_TARGET_ISA',['../user_guide.html#wireless_sdk_target_isa_env',1,'']]]
];
