var searchData=
[
  ['n_5fcp_0',['n_cp',['../structbblib__ta__request.html#a81d17d7b8ed91861c5c038ecfc17c682',1,'bblib_ta_request']]],
  ['n_5ffft_5fsize_1',['n_fft_size',['../structbblib__ta__request.html#aca5373b0f95e7075744a95a7717750e5',1,'bblib_ta_request::n_fft_size'],['../structbblib__fo__request.html#a5605eb0d3c85c3dd04bd379ddd29bd5e',1,'bblib_fo_request::n_fft_size']]],
  ['n_5ffullband_5fsc_2',['n_fullband_sc',['../structbblib__ta__request.html#a69c07b0c06bfd501a4ab055493f10ba6',1,'bblib_ta_request']]],
  ['ncb_3',['ncb',['../structbblib__rate__dematching__5gnr__request.html#aaea88c1e065441d7b076360281d56017',1,'bblib_rate_dematching_5gnr_request::ncb'],['../structbblib__rate__match__ul__request.html#ab2ead0bec8716f1a9d3b1da48c2a61fc',1,'bblib_rate_match_ul_request::ncb'],['../structbblib__harq__combine__ul__request.html#a218d25a30dd46034dab622c364420b0b',1,'bblib_harq_combine_ul_request::ncb'],['../structbblib__deinterleave__ul__request.html#a188444284ceb5036b84d94d8edb01d63',1,'bblib_deinterleave_ul_request::ncb'],['../structbblib__turbo__adapter__ul__request.html#a91318c3372a6b9c02f96982aeb7ed678',1,'bblib_turbo_adapter_ul_request::ncb'],['../structbblib__LDPC__ratematch__5gnr__request.html#a7c008f14a9ff859ad78188f76127f110',1,'bblib_LDPC_ratematch_5gnr_request::Ncb']]],
  ['nl_4',['NL',['../structbblib__rate__match__dl__request.html#a4f4b4cee6e481e52e2c883ce170007ff',1,'bblib_rate_match_dl_request']]],
  ['nlen_5',['nlen',['../structbblib__LDPC__ratematch__5gnr__request.html#a73ff60514efe98cc31ee6b9179343786',1,'bblib_LDPC_ratematch_5gnr_request::nLen'],['../structbblib__rate__match__dl__request.html#a4682da439914d6a7fc275b9c2c3f3107',1,'bblib_rate_match_dl_request::nLen']]],
  ['nrows_6',['nrows',['../structbblib__ldpc__decoder__5gnr__request.html#ab3ffbda9910784c600c98f0195dbb006',1,'bblib_ldpc_decoder_5gnr_request::nRows'],['../structbblib__ldpc__encoder__5gnr__request.html#a2a470ae702047cff99212739550fd539',1,'bblib_ldpc_encoder_5gnr_request::nRows']]],
  ['nsoft_7',['Nsoft',['../structbblib__rate__match__dl__request.html#a3ce4c9f5e64663ab44bd8f1ed2a9fb52',1,'bblib_rate_match_dl_request']]],
  ['nullindex_8',['nullIndex',['../structbblib__LDPC__ratematch__5gnr__request.html#a48efcfa671770cb8978725d3733e394a',1,'bblib_LDPC_ratematch_5gnr_request']]],
  ['num_5fbits_9',['num_bits',['../structbblib__prbs__request.html#a6466e01835d0623eed170d98a5b3d146',1,'bblib_prbs_request::num_bits'],['../structbblib__prbs__response.html#a11b8540105797900c9924d28cdfc4088',1,'bblib_prbs_response::num_bits']]],
  ['num_5fof_5fnull_10',['num_of_null',['../structbblib__rate__dematching__5gnr__request.html#a9f87c3379b581e37e272da2aca98280a',1,'bblib_rate_dematching_5gnr_request']]],
  ['numbercodeblocks_11',['numberCodeblocks',['../structbblib__ldpc__encoder__5gnr__request.html#a3de222259d500048a2b5a0593583962e',1,'bblib_ldpc_encoder_5gnr_request']]],
  ['numchannelllrs_12',['numChannelLlrs',['../structbblib__ldpc__decoder__5gnr__request.html#afe7b0ba4aaa5018d244dab332e01b03a',1,'bblib_ldpc_decoder_5gnr_request']]],
  ['numfillerbits_13',['numFillerBits',['../structbblib__ldpc__decoder__5gnr__request.html#a9bd33bab6e7cc4fb09a2ae234c2cc0a5',1,'bblib_ldpc_decoder_5gnr_request']]],
  ['nummsgbits_14',['numMsgBits',['../structbblib__ldpc__decoder__5gnr__response.html#a1f1b1c3982ead9af51d7efb9f45463be',1,'bblib_ldpc_decoder_5gnr_response']]]
];
