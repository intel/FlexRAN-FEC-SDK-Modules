var searchData=
[
  ['max_5fiter_5fnum_0',['max_iter_num',['../structbblib__turbo__decoder__request.html#af923d29682bb2dcae812f2568fe75423',1,'bblib_turbo_decoder_request']]],
  ['maxiterations_1',['maxIterations',['../structbblib__ldpc__decoder__5gnr__request.html#ac6f83ad1ace7c6c406204d0659566955',1,'bblib_ldpc_decoder_5gnr_request']]],
  ['mdl_5fharq_2',['MDL_HARQ',['../structbblib__rate__match__dl__request.html#a4f268d2d48743c91b47c4d8dd18f0709',1,'bblib_rate_match_dl_request']]],
  ['modulation_5forder_3',['modulation_order',['../structbblib__rate__dematching__5gnr__request.html#a967dd50532ac4893e058ea48fed80e10',1,'bblib_rate_dematching_5gnr_request']]]
];
