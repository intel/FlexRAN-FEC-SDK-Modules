var searchData=
[
  ['qm_0',['qm',['../structbblib__LDPC__ratematch__5gnr__request.html#a0f24003587dc5ea1db2c3204723bb9f5',1,'bblib_LDPC_ratematch_5gnr_request::Qm'],['../structbblib__rate__match__dl__request.html#a8794554f1f083a7ae5041a458ab5879d',1,'bblib_rate_match_dl_request::Qm']]]
];
