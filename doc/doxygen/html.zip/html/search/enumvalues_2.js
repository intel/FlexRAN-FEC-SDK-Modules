var searchData=
[
  ['cpu_5fgeneric_0',['CPU_GENERIC',['../common__typedef__sdk_8h.html#a4c160ac3b177a2fde8738ef01e58494caa76b502aab6c6110511beaf3297aab5f',1,'common_typedef_sdk.h']]]
];
