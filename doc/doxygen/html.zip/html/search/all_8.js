var searchData=
[
  ['im_0',['im',['../structcomplex__int8__t.html#a87dc610f8076501f9ef574c71092b22a',1,'complex_int8_t::im'],['../structcomplex__int16__t.html#a9eeeb4f5797f14a45b9d06ccc99786dd',1,'complex_int16_t::im'],['../structcomplex__int32__t.html#a444cb55b29938e058b49ed92a9cffaee',1,'complex_int32_t::im'],['../structcomplex__float.html#a96d96e19d16b6b08e43fb799c6406f0a',1,'complex_float::im'],['../structcomplex__double.html#a24c8308c824e9b7256bd1beccb571520',1,'complex_double::im']]],
  ['in_20an_20application_1',['Using the SDK library in an application',['../user_guide.html#sdk_library_use',1,'']]],
  ['initialization_2',['Module Initialization',['../prg_guide.html#module_init',1,'']]],
  ['input_3',['input',['../structbblib__ldpc__encoder__5gnr__request.html#af6f01e53c205156680966f23427774c8',1,'bblib_ldpc_encoder_5gnr_request::input'],['../structbblib__LDPC__ratematch__5gnr__request.html#a88134dc61c8c081cebe91d59566359de',1,'bblib_LDPC_ratematch_5gnr_request::input'],['../structbblib__turbo__decoder__request.html#a84a82e8f1467bb7f61572cd2fc0c065a',1,'bblib_turbo_decoder_request::input']]],
  ['input_5fwin_4',['input_win',['../structbblib__turbo__encoder__request.html#a6904cefbcbf69320c25e17e1a7afaaf6',1,'bblib_turbo_encoder_request']]],
  ['installation_5',['Google* test installation',['../user_guide.html#gtest_install',1,'']]],
  ['installation_20instructions_6',['installation instructions',['../user_guide.html#install_sec',1,'Installation instructions'],['../user_guide.html#install_instructions',1,'Installation instructions']]],
  ['instruction_5fcpu_5fsupport_7',['instruction_cpu_support',['../common__typedef__sdk_8h.html#a4c160ac3b177a2fde8738ef01e58494c',1,'common_typedef_sdk.h']]],
  ['instructions_8',['instructions',['../user_guide.html#build_instr',1,'Build instructions'],['../user_guide.html#install_sec',1,'Installation instructions'],['../user_guide.html#install_instructions',1,'Installation instructions']]],
  ['introduction_9',['introduction',['../index.html#intro_sec',1,'Introduction'],['../user_guide.html#user_guide_intro',1,'Introduction'],['../prg_guide.html#prg_guide_intro',1,'Introduction']]],
  ['isinverted_10',['isinverted',['../structbblib__rate__match__ul__request.html#ab005f23362bd7d251e5e70f9a8706255',1,'bblib_rate_match_ul_request::isinverted'],['../structbblib__turbo__adapter__ul__request.html#a9eda24d557f19bc9e6985a1468f02c8d',1,'bblib_turbo_adapter_ul_request::isinverted']]],
  ['isretx_11',['isretx',['../structbblib__rate__dematching__5gnr__request.html#ac9c9bbb71c1950a37067e73e1675abf2',1,'bblib_rate_dematching_5gnr_request::isretx'],['../structbblib__rate__match__ul__request.html#a048ad1ae1ce69b6bb123278842e40900',1,'bblib_rate_match_ul_request::isretx'],['../structbblib__harq__combine__ul__request.html#ac49c2678e7155ec7b05cc5ca0d6451fc',1,'bblib_harq_combine_ul_request::isretx']]],
  ['iterationattermination_12',['iterationAtTermination',['../structbblib__ldpc__decoder__5gnr__response.html#a7056f5a001b8f425caa6b57cf4efe48b',1,'bblib_ldpc_decoder_5gnr_response']]]
];
