var searchData=
[
  ['get_5fsys_5fpara_0',['get_sys_para',['../phy__tafo__table__gen_8h.html#aacbbb130015afb3f158fd6ee7b699125',1,'phy_tafo_table_gen.h']]]
];
