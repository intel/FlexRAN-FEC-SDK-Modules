var searchData=
[
  ['base_5fgraph_0',['base_graph',['../structbblib__rate__dematching__5gnr__request.html#a2f5d8c4161b6bf4ca2c9bfbdd2ec75c8',1,'bblib_rate_dematching_5gnr_request']]],
  ['basegraph_1',['basegraph',['../structbblib__ldpc__decoder__5gnr__request.html#ac421d125414c08d39450e84a7bb07691',1,'bblib_ldpc_decoder_5gnr_request::baseGraph'],['../structbblib__ldpc__encoder__5gnr__request.html#a0d9bdc0eae95e92aa804003b052a3c65',1,'bblib_ldpc_encoder_5gnr_request::baseGraph'],['../structbblib__LDPC__ratematch__5gnr__request.html#a2bf6ab92a9bac5132add8dc2a2f03142',1,'bblib_LDPC_ratematch_5gnr_request::baseGraph']]],
  ['bits_2',['bits',['../structbblib__prbs__response.html#a4f6ee0c5c4335c01268f102d3c262a55',1,'bblib_prbs_response']]],
  ['bypass_5frvidx_3',['bypass_rvidx',['../structbblib__rate__match__dl__request.html#aadfab1380f947f9622cec4a562329756',1,'bblib_rate_match_dl_request']]]
];
