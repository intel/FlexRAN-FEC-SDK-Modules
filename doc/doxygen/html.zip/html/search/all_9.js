var searchData=
[
  ['k_0',['k',['../structbblib__turbo__decoder__request.html#a98b2b7594d0bcb6244ac44ee5d0df994',1,'bblib_turbo_decoder_request']]],
  ['k0_1',['k0',['../structbblib__rate__dematching__5gnr__request.html#af827d140770203e13becc6d36b342fb1',1,'bblib_rate_dematching_5gnr_request']]],
  ['k0withoutnull_2',['k0withoutnull',['../structbblib__rate__match__ul__request.html#a9a0be0af9bcfadc2d52c230184335f64',1,'bblib_rate_match_ul_request::k0withoutnull'],['../structbblib__harq__combine__ul__request.html#a8c3ab96097af349d8ec206cb47ba8a3e',1,'bblib_harq_combine_ul_request::k0withoutnull']]],
  ['k_5fidx_3',['k_idx',['../structbblib__turbo__decoder__request.html#a7b82a3abbf6d88349fab3ce22227b5a9',1,'bblib_turbo_decoder_request']]],
  ['kidx_4',['Kidx',['../structbblib__rate__match__dl__request.html#a1331df76d4998c71e83140c9476b6b44',1,'bblib_rate_match_dl_request']]],
  ['kmimo_5',['KMIMO',['../structbblib__rate__match__dl__request.html#ae4a1f966cbb59cf559e80d050e28ed37',1,'bblib_rate_match_dl_request']]]
];
