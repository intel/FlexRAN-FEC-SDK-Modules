var searchData=
[
  ['manual_0',['FlexRAN™ FEC SDK User manual',['../user_guide.html',1,'index']]],
  ['modules_1',['FlexRAN™ FEC SDK Modules',['../index.html',1,'']]]
];
