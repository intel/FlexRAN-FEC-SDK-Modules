var searchData=
[
  ['user_20manual_0',['FlexRAN™ FEC SDK User manual',['../user_guide.html',1,'index']]]
];
