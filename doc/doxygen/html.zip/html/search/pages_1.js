var searchData=
[
  ['guide_0',['FlexRAN™ FEC SDK Programmers Guide',['../prg_guide.html',1,'index']]]
];
