var searchData=
[
  ['data_0',['data',['../structbblib__crc__request.html#afa4b3b86f878a7a7893a9cf5bb6f2a5a',1,'bblib_crc_request::data'],['../structbblib__crc__response.html#ae118bb0cf7af262f3a4705c1031858ed',1,'bblib_crc_response::data']]],
  ['decompprbnum_1',['decompPRBNum',['../structbblib__pusch__xran__decomp.html#ad2d806f1ce4b19c5512abc133053a435',1,'bblib_pusch_xran_decomp']]],
  ['decompprbstart_2',['decompPRBStart',['../structbblib__pusch__xran__decomp.html#ab8a7aa6ce334c02b34c4b04e7aba27a0',1,'bblib_pusch_xran_decomp']]],
  ['dependencies_3',['System requirements and dependencies',['../user_guide.html#dependencies',1,'']]],
  ['direction_4',['direction',['../structbblib__rate__match__dl__request.html#a4c68fba251f62daf5c176d2bd5a400c8',1,'bblib_rate_match_dl_request']]],
  ['doxygen_20comments_5',['Doxygen Comments',['../prg_guide.html#comments',1,'']]],
  ['dummy_6',['dummy',['../structbblib__rate__dematching__5gnr__response.html#a57dde21f50cba181ea0bceb6fb460581',1,'bblib_rate_dematching_5gnr_response']]],
  ['dvec_5finc_2eh_7',['dvec_inc.h',['../dvec__inc_8h.html',1,'']]]
];
