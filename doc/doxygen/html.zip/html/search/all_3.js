var searchData=
[
  ['data_0',['data',['../structbblib__crc__request.html#afa4b3b86f878a7a7893a9cf5bb6f2a5a',1,'bblib_crc_request::data'],['../structbblib__crc__response.html#ae118bb0cf7af262f3a4705c1031858ed',1,'bblib_crc_response::data']]],
  ['dependencies_1',['System requirements and dependencies',['../user_guide.html#dependencies',1,'']]],
  ['direction_2',['direction',['../structbblib__rate__match__dl__request.html#a4c68fba251f62daf5c176d2bd5a400c8',1,'bblib_rate_match_dl_request']]],
  ['doxygen_20comments_3',['Doxygen Comments',['../prg_guide.html#comments',1,'']]],
  ['dummy_4',['dummy',['../structbblib__rate__dematching__5gnr__response.html#a57dde21f50cba181ea0bceb6fb460581',1,'bblib_rate_dematching_5gnr_response']]]
];
