var searchData=
[
  ['ag_5fbuf_0',['ag_buf',['../structbblib__turbo__decoder__response.html#a5275fc861f027f260b01703266c258ae',1,'bblib_turbo_decoder_response']]],
  ['all_20tests_1',['Running all tests',['../user_guide.html#all_tests',1,'']]],
  ['an_20application_2',['Using the SDK library in an application',['../user_guide.html#sdk_library_use',1,'']]],
  ['and_20dependencies_3',['System requirements and dependencies',['../user_guide.html#dependencies',1,'']]],
  ['api_20standards_4',['API Standards',['../prg_guide.html#api_standard',1,'']]],
  ['application_5',['Using the SDK library in an application',['../user_guide.html#sdk_library_use',1,'']]],
  ['avx_6',['AVX',['../common__typedef__sdk_8h.html#a4c160ac3b177a2fde8738ef01e58494ca0f2500907bbad2fb795fba8fafd31b2a',1,'common_typedef_sdk.h']]],
  ['avx2_7',['AVX2',['../common__typedef__sdk_8h.html#a4c160ac3b177a2fde8738ef01e58494ca7b9822126e7b712535af7b882409bf8b',1,'common_typedef_sdk.h']]],
  ['avx_5f512_8',['AVX_512',['../common__typedef__sdk_8h.html#a4c160ac3b177a2fde8738ef01e58494ca90b287f46b6b1d6837db75d9822aa45b',1,'common_typedef_sdk.h']]]
];
