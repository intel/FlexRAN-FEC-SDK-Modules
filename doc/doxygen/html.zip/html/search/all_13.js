var searchData=
[
  ['unit_20tests_0',['Running the unit tests',['../user_guide.html#usage_instr',1,'']]],
  ['user_20manual_1',['FlexRAN™ FEC SDK User manual',['../user_guide.html',1,'index']]],
  ['using_20the_20sdk_20library_20in_20an_20application_2',['Using the SDK library in an application',['../user_guide.html#sdk_library_use',1,'']]]
];
