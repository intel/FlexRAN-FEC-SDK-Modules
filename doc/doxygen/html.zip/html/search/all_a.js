var searchData=
[
  ['len_0',['len',['../structbblib__crc__request.html#abff068fa5f2ce3b9273e33a41e020290',1,'bblib_crc_request::len'],['../structbblib__crc__response.html#a693df4d5b295fab240b381f8aa891a1a',1,'bblib_crc_response::len']]],
  ['length_1',['length',['../structbblib__turbo__encoder__request.html#adf43315e4b7262a0e9cd053d0723ba66',1,'bblib_turbo_encoder_request']]],
  ['library_20in_20an_20application_2',['Using the SDK library in an application',['../user_guide.html#sdk_library_use',1,'']]]
];
