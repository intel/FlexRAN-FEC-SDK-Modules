var searchData=
[
  ['avx_0',['AVX',['../common__typedef__sdk_8h.html#a4c160ac3b177a2fde8738ef01e58494ca0f2500907bbad2fb795fba8fafd31b2a',1,'common_typedef_sdk.h']]],
  ['avx2_1',['AVX2',['../common__typedef__sdk_8h.html#a4c160ac3b177a2fde8738ef01e58494ca7b9822126e7b712535af7b882409bf8b',1,'common_typedef_sdk.h']]],
  ['avx_5f512_2',['AVX_512',['../common__typedef__sdk_8h.html#a4c160ac3b177a2fde8738ef01e58494ca90b287f46b6b1d6837db75d9822aa45b',1,'common_typedef_sdk.h']]]
];
