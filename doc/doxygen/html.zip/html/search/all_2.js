var searchData=
[
  ['c_0',['c',['../structbblib__rate__match__dl__request.html#a1444e7b7072b22210b0fce32688d9fe0',1,'bblib_rate_match_dl_request::C'],['../structbblib__turbo__decoder__request.html#a9eed4c145a0b71763a8abaae09c1f9c5',1,'bblib_turbo_decoder_request::c']]],
  ['c_5finit_1',['c_init',['../structbblib__prbs__request.html#a6edca354a3dbe8a573f4b4e1e880d977',1,'bblib_prbs_request']]],
  ['case_5fid_2',['case_id',['../structbblib__turbo__encoder__request.html#a8209d30b875b7b5812db258e35dc1768',1,'bblib_turbo_encoder_request']]],
  ['cb_5fbuf_3',['cb_buf',['../structbblib__turbo__decoder__response.html#af538751e1ce0dc56ddb5ca828ff8ec83',1,'bblib_turbo_decoder_response']]],
  ['check_5fpassed_4',['check_passed',['../structbblib__crc__response.html#a14029a7e9d5f6401ee5a1f6e97b024a7',1,'bblib_crc_response']]],
  ['circ_5fbuffer_5',['circ_buffer',['../structbblib__deinterleave__ul__request.html#a9726643b14ad09d2d3dbf8dbaa63fa0e',1,'bblib_deinterleave_ul_request']]],
  ['circular_5fbuffer_5fformat_6',['circular_buffer_format',['../phy__rate__match_8h.html#a703c3b1d20e38963e545c172f7534deb',1,'phy_rate_match.h']]],
  ['cmake_5fbuild_5ftype_7',['CMAKE_BUILD_TYPE',['../user_guide.html#cmake_build_type_env',1,'']]],
  ['coding_20style_8',['Coding Style',['../prg_guide.html#code_style',1,'']]],
  ['comments_9',['Doxygen Comments',['../prg_guide.html#comments',1,'']]],
  ['common_5ftypedef_5fsdk_2eh_10',['common_typedef_sdk.h',['../common__typedef__sdk_8h.html',1,'']]],
  ['compactedmessagebytes_11',['compactedMessageBytes',['../structbblib__ldpc__decoder__5gnr__response.html#a9cac0aed1647f9891b6c11004be200f3',1,'bblib_ldpc_decoder_5gnr_response']]],
  ['complex_5fdouble_12',['complex_double',['../structcomplex__double.html',1,'']]],
  ['complex_5ffloat_13',['complex_float',['../structcomplex__float.html',1,'']]],
  ['complex_5fint16_5ft_14',['complex_int16_t',['../structcomplex__int16__t.html',1,'']]],
  ['complex_5fint32_5ft_15',['complex_int32_t',['../structcomplex__int32__t.html',1,'']]],
  ['complex_5fint8_5ft_16',['complex_int8_t',['../structcomplex__int8__t.html',1,'']]],
  ['convention_17',['convention',['../prg_guide.html#module_names',1,'Module Naming Convention'],['../prg_guide.html#test_bench',1,'Test Bench Naming Convention']]],
  ['conventions_18',['Naming Conventions',['../prg_guide.html#naming',1,'']]],
  ['cpu_5fgeneric_19',['CPU_GENERIC',['../common__typedef__sdk_8h.html#a4c160ac3b177a2fde8738ef01e58494caa76b502aab6c6110511beaf3297aab5f',1,'common_typedef_sdk.h']]],
  ['crc_5fvalue_20',['crc_value',['../structbblib__crc__response.html#aaf7bb19852e12b232820bd88ade20155',1,'bblib_crc_response']]]
];
