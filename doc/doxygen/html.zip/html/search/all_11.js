var searchData=
[
  ['sdk_20build_0',['SDK build',['../user_guide.html#sdk_build',1,'']]],
  ['sdk_20environment_20variables_1',['SDK environment variables',['../user_guide.html#sdk_env_vars',1,'']]],
  ['sdk_20library_20in_20an_20application_2',['Using the SDK library in an application',['../user_guide.html#sdk_library_use',1,'']]],
  ['sdk_20modules_3',['FlexRAN™ FEC SDK Modules',['../index.html',1,'']]],
  ['sdk_20programmers_20guide_4',['FlexRAN™ FEC SDK Programmers Guide',['../prg_guide.html',1,'index']]],
  ['sdk_20user_20manual_5',['FlexRAN™ FEC SDK User manual',['../user_guide.html',1,'index']]],
  ['sdk_5fversion_2eh_6',['sdk_version.h',['../sdk__version_8h.html',1,'']]],
  ['snc_7',['SNC',['../common__typedef__sdk_8h.html#a4c160ac3b177a2fde8738ef01e58494ca90a568137307a6ee0e0115b59b2c4e7f',1,'common_typedef_sdk.h']]],
  ['sse4_5f2_8',['SSE4_2',['../common__typedef__sdk_8h.html#a4c160ac3b177a2fde8738ef01e58494ca4c63ae1c44ecd28b978e615d7773e15f',1,'common_typedef_sdk.h']]],
  ['standards_9',['API Standards',['../prg_guide.html#api_standard',1,'']]],
  ['start_5fnull_5findex_10',['start_null_index',['../structbblib__rate__dematching__5gnr__request.html#a865b0e21d45c13e898c86b0ebca9663a',1,'bblib_rate_dematching_5gnr_request']]],
  ['style_11',['Coding Style',['../prg_guide.html#code_style',1,'']]],
  ['symnum_12',['symNum',['../structbblib__pusch__xran__decomp.html#a8dc7e3ce4134b465282a47b5df7dd713',1,'bblib_pusch_xran_decomp']]],
  ['system_20requirements_20and_20dependencies_13',['System requirements and dependencies',['../user_guide.html#dependencies',1,'']]]
];
