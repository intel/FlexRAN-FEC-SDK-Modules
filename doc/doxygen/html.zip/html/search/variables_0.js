var searchData=
[
  ['ag_5fbuf_0',['ag_buf',['../structbblib__turbo__decoder__response.html#a5275fc861f027f260b01703266c258ae',1,'bblib_turbo_decoder_response']]],
  ['antnum_1',['antNum',['../structbblib__pusch__xran__decomp.html#ac58bc760311df29bbdacf4f95bc64acf',1,'bblib_pusch_xran_decomp']]]
];
