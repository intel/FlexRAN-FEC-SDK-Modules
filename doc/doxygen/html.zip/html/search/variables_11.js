var searchData=
[
  ['varnodes_0',['varnodes',['../structbblib__ldpc__decoder__5gnr__request.html#a81f80cea37a3f15e2f19ba45555dbcab',1,'bblib_ldpc_decoder_5gnr_request::varNodes'],['../structbblib__ldpc__decoder__5gnr__response.html#aa4a3533b55a5ec1e01e3f863d93c6b4b',1,'bblib_ldpc_decoder_5gnr_response::varNodes']]]
];
